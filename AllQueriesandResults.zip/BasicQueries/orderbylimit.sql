-- Top 5 highest sales records
SELECT * 
FROM walmart_sales 
ORDER BY Weekly_Sales DESC 
LIMIT 5;