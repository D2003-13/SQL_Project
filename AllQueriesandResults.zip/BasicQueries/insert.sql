-- Add a new record
INSERT INTO walmart_sales 
VALUES (45, '2023-01-01', 2500000.00, FALSE, 65.20, 3.45, 220.4567, 6.70);