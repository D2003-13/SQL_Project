-- Find unique store numbers
SELECT DISTINCT Store 
FROM walmart_sales 
ORDER BY Store;