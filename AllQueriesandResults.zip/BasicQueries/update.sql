-- Update records
UPDATE walmart_sales
SET Holiday_Flag = TRUE
WHERE Date = '2010-12-31' AND Store = 1;