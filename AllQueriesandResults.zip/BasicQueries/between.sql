-- Find sales between two dates
SELECT * 
FROM walmart_sales 
WHERE Date BETWEEN '2010-02-05' AND '2010-02-12';