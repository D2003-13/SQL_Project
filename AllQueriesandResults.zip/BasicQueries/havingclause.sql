-- Stores with total sales over $50 million
SELECT Store, SUM(Weekly_Sales) AS Total_Sales
FROM walmart_sales
GROUP BY Store
HAVING SUM(Weekly_Sales) > 50000000
ORDER BY Total_Sales DESC;