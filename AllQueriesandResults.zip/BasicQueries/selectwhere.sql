-- Basic select with where clause
SELECT Store, Date, Weekly_Sales 
FROM walmart_sales 
WHERE Store = 1 AND Holiday_Flag = TRUE;