-- Add a new column
ALTER TABLE walmart_sales ADD COLUMN Sales_Category VARCHAR(20);

-- Update the new column based on sales amount
UPDATE walmart_sales
SET Sales_Category = CASE 
    WHEN Weekly_Sales < 1000000 THEN 'Low'
    WHEN Weekly_Sales BETWEEN 1000000 AND 2000000 THEN 'Medium'
    ELSE 'High'
END;

select * from walmart_sales;