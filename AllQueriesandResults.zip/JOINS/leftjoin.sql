-- Left join to see all sales records even if store details are missing
SELECT s.Store, s.Date, s.Weekly_Sales, d.Size_SqFt, d.Location_Type
FROM walmart_sales s
LEFT JOIN store_details d ON s.Store = d.Store
WHERE s.Weekly_Sales > 2000000;