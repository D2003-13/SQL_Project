-- Full outer join to see all records from both tables
SELECT s.Store AS Sales_Store, d.Store AS Details_Store,
       s.Weekly_Sales, d.Size_SqFt
FROM walmart_sales s
FULL OUTER JOIN store_details d ON s.Store = d.Store;