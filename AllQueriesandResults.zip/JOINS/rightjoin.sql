-- Right join to see all store details even if sales data is missing
SELECT d.Store, d.Size_SqFt, d.Location_Type, 
       COUNT(s.Weekly_Sales) AS Sales_Records,
       AVG(s.Weekly_Sales) AS Avg_Sales
FROM walmart_sales s
RIGHT JOIN store_details d ON s.Store = d.Store
GROUP BY d.Store, d.Size_SqFt, d.Location_Type;