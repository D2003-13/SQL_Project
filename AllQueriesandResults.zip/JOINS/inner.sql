-- Create a store details table for join examples
CREATE TABLE store_details (
    Store INTEGER PRIMARY KEY,
    Size_SqFt INTEGER,
    Location_Type VARCHAR(50),
    Region VARCHAR(50)
);

-- Insert sample data (in a real scenario, you'd have this data)
INSERT INTO store_details
VALUES 
    (1, 100000, 'Urban', 'Northeast'),
    (2, 120000, 'Suburban', 'Midwest'),
    -- Add more stores as needed
    (45, 95000, 'Rural', 'South');

-- Inner join to get sales with store details
SELECT s.Store, s.Date, s.Weekly_Sales, d.Size_SqFt, d.Location_Type
FROM walmart_sales s
INNER JOIN store_details d ON s.Store = d.Store
WHERE s.Date = '2011-12-23';