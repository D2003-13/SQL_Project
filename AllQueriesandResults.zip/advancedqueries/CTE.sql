-- Using CTE to analyze holiday vs non-holiday sales
WITH holiday_sales AS (
    SELECT 
        Store,
        SUM(Weekly_Sales) AS Holiday_Sales,
        COUNT(*) AS Holiday_Weeks
    FROM walmart_sales
    WHERE Holiday_Flag = TRUE
    GROUP BY Store
),
non_holiday_sales AS (
    SELECT 
        Store,
        SUM(Weekly_Sales) AS Non_Holiday_Sales,
        COUNT(*) AS Non_Holiday_Weeks
    FROM walmart_sales
    WHERE Holiday_Flag = FALSE
    GROUP BY Store
)
SELECT 
    h.Store,
    h.Holiday_Sales,
    nh.Non_Holiday_Sales,
    h.Holiday_Sales / h.Holiday_Weeks AS Avg_Holiday_Sales,
    nh.Non_Holiday_Sales / nh.Non_Holiday_Weeks AS Avg_Non_Holiday_Sales
FROM holiday_sales h
JOIN non_holiday_sales nh ON h.Store = nh.Store
ORDER BY (h.Holiday_Sales / h.Holiday_Weeks) / (nh.Non_Holiday_Sales / nh.Non_Holiday_Weeks) DESC;