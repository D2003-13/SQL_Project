-- Sales by year and month
SELECT 
    EXTRACT(YEAR FROM Date) AS Year,
    EXTRACT(MONTH FROM Date) AS Month,
    SUM(Weekly_Sales) AS Monthly_Sales
FROM walmart_sales
GROUP BY Year, Month
ORDER BY Year, Month;

-- Sales by day of week
SELECT 
    EXTRACT(DOW FROM Date) AS Day_of_Week,
    AVG(Weekly_Sales) AS Avg_Sales
FROM walmart_sales
GROUP BY Day_of_Week
ORDER BY Day_of_Week;