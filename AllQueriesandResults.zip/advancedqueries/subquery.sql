-- Stores with above average sales
SELECT Store, SUM(Weekly_Sales) AS Total_Sales
FROM walmart_sales
GROUP BY Store
HAVING SUM(Weekly_Sales) > (
    SELECT AVG(store_sales)
    FROM (
        SELECT SUM(Weekly_Sales) AS store_sales
        FROM walmart_sales
        GROUP BY Store
    ) AS avg_sales
)
ORDER BY Total_Sales DESC;