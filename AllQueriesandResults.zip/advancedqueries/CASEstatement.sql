-- Categorize sales performance
SELECT 
    Store,
    Date,
    Weekly_Sales,
    CASE 
        WHEN Weekly_Sales > 2500000 THEN 'Excellent'
        WHEN Weekly_Sales BETWEEN 1500000 AND 2500000 THEN 'Good'
        WHEN Weekly_Sales BETWEEN 1000000 AND 1500000 THEN 'Average'
        ELSE 'Below Average'
    END AS Performance
FROM walmart_sales
ORDER BY Store, Date;