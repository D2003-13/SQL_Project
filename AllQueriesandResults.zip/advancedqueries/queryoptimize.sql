-- Create indexes for better performance
CREATE INDEX idx_store ON walmart_sales(Store);
CREATE INDEX idx_date ON walmart_sales(Date);
CREATE INDEX idx_holiday ON walmart_sales(Holiday_Flag);

-- Analyze the table for query planner
ANALYZE walmart_sales;

-- Use EXPLAIN to analyze query performance
EXPLAIN ANALYZE
SELECT Store, SUM(Weekly_Sales)
FROM walmart_sales
WHERE Date BETWEEN '2011-01-01' AND '2011-12-31'
GROUP BY Store;