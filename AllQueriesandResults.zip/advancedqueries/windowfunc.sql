-- Running total of sales by store
SELECT 
    Store, 
    Date, 
    Weekly_Sales,
    SUM(Weekly_Sales) OVER (PARTITION BY Store ORDER BY Date) AS Running_Total
FROM walmart_sales
ORDER BY Store, Date;

-- Rank stores by sales in each year
WITH yearly_sales AS (
    SELECT 
        Store,
        EXTRACT(YEAR FROM Date) AS Year,
        SUM(Weekly_Sales) AS Total_Sales
    FROM walmart_sales
    GROUP BY Store, Year
)
SELECT 
    Store,
    Year,
    Total_Sales,
    RANK() OVER (PARTITION BY Year ORDER BY Total_Sales DESC) AS Sales_Rank
FROM yearly_sales
ORDER BY Year, Sales_Rank;